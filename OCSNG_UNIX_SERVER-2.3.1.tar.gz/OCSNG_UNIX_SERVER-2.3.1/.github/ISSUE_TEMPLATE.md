*It's hard to solve a problem when important details are missing, that why we added this template, to help you and us.*

### General informations
Operating system : 

### Server informations
Perl version : 
Mysql / Mariadb / Percona version :  

### OCS Inventory informations
Ocs server version : 

### Problem's description
*Describe your problem here*

