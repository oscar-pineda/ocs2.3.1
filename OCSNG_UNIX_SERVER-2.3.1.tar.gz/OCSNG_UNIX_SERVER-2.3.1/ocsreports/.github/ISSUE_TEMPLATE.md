*It's hard to solve a problem when important details are missing, that why we added this template, to help you and us.*

### General informations
Operating system : 

### Server informations
Php version : 
Mysql / Mariadb / Percona version : 
Apache version : 

### OCS Inventory informations
Ocsreports version : 

### Problem's description
*Describe your problem here*

